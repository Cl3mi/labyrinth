package labyrinth.game.enums;

public enum MoveState {
    PLACE_TILE,
    MOVE,
}
