package labyrinth.game.enums;

public enum RoomState {
    LOBBY,
    IN_GAME,
    FINISHED
}
